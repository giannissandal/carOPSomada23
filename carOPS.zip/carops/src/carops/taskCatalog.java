package carops;
import java.util.ArrayList;
import java.util.List;

public class taskCatalog {

	private List<task> tasks;

    public taskCatalog() {
        tasks = new ArrayList<>();
    }

    public void addTask(task task) {
        tasks.add(task);
    }

    public List<task> getTasks() {
        return tasks;
    }
	
	
	
	public String getCondition() {
		// TODO - implement taskCatalog.getCondition
		throw new UnsupportedOperationException();
	}

}