package carops;

public class task {

	private repair repair;
	private int taskDuration;
	private String partType;
	private int partNumber;
	private String taskCondition;

	public task(repair repair, int taskDuration, String partType, int partNumber, String taskCondition) {
        this.repair = repair;
        this.taskDuration = taskDuration;
        this.partType = partType;
        this.partNumber = partNumber;
        this.taskCondition = taskCondition;
    }

    // Getter methods
    public repair getRepair() {
        return repair;
    }

    public int getDuration() {
        return taskDuration;
    }

    public String getPartName() {
        return partType;
    }

    public int getPartNumber() {
        return partNumber;
    }

    public String getTaskCondition() {
        return taskCondition;
    }
	
	
	
	public String getCondition() {
		// TODO - implement task.getCondition
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param taskCondition
	 */
	public void setCondition(String taskCondition) {
		// TODO - implement task.setCondition
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param taskDuration
	 */
	public Integer setDuration(int taskDuration) {
		// TODO - implement task.setDuration
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partNumber
	 */
	public Integer setPartNumber(int partNumber) {
		// TODO - implement task.setPartNumber
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partType
	 */
	public String setPartType(int partType) {
		// TODO - implement task.setPartType
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param taskCondition
	 */
	public String setCondition(int taskCondition) {
		// TODO - implement task.setCondition
		throw new UnsupportedOperationException();
	}

}