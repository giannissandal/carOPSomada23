package carops;

public class repair {

	private String name;
	private double cost;
	
	public repair(String name, double cost) {
        this.name = name;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public double getCost() {
        return cost;
    }

	
	
	
	
	
	
	
	public String getRepairName() {
		return this.name;
	}

	/**
	 * 
	 * @param repairName
	 */
	public void setRepairName(String repairName) {
		this.name = repairName;
	}

	public Double getRepairCost() {
		return this.cost;
	}

	/**
	 * 
	 * @param repairCost
	 */
	public void setRepairCost(Double repairCost) {
		this.cost = repairCost;
	}

}