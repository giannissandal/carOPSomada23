package carops;
import java.util.Scanner;
import carops.card;
import java.util.ArrayList;
import java.util.List;


public class main {

	public static void main(String[] args) {						
		Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Menu:");
            System.out.println("1. Dhmiourgia Kartelas");
            System.out.println("2. Nea Ergasia");
            System.out.println("3. Ergasies Episkeyhs");
            System.out.println("0. Eksodos");
            System.out.print("Epilekse: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Dhmiourgia Neas Kartelas...");
                    System.out.print("Onoma: ");
                    String name = scanner.next();

                    System.out.print("Epwnymo: ");
                    String surname = scanner.next();

                    System.out.print("Arithmos Thlefwnou: ");
                    float phoneNumber = scanner.nextFloat();

                    System.out.print("Dieythinsi: ");
                    String address = scanner.next();

                    System.out.print("E-Mail: ");
                    String email = scanner.next();

                    System.out.print("Pinakida: ");
                    String plateNumber = scanner.next();

                    card newCard = new card();
                    newCard.setName(name);
                    newCard.setSurname(surname);
                    newCard.setPhoneNumber(phoneNumber);
                    newCard.setAddress(address);
                    newCard.setEmail(email);
                    newCard.setPlateNumber(plateNumber);
                    
                    System.out.println("H kartela dhmiourghthike epituxws!");
                    System.out.println("Leptomeries Kartelas:");
                    System.out.println("Onoma: " + newCard.getName());
                    System.out.println("Epwnymo: " + newCard.getSurname());
                    System.out.println("Arithmos Thlefwnou: " + newCard.getPhoneNumber());
                    System.out.println("Dieythinsi: " + newCard.getAddress());
                    System.out.println("E-mail: " + newCard.getEmail());
                    System.out.println("Pinakida: " + newCard.getPlateNumber());


                    break;
                case 2:
                    System.out.println("Dhmiourgia Neas Ergasias...");
                    // Add your code for creating a task here
                    break;
                case 3:
                	System.out.println("Ergasies Episkeuhs...");
                	repair oilChange = new repair("Allagh Ladiwn", 20);
                    repair filterChange = new repair("Allagh Filtrou Kampinas", 5);
                    repair brakeService = new repair("Synthrhsh Frenwn", 30);

                    repairCatalog repairCatalog = new repairCatalog();
                    repairCatalog.addRepair(oilChange);
                    repairCatalog.addRepair(filterChange);
                    repairCatalog.addRepair(brakeService);

                    repairCatalog.printRepairs();
                    
                    
                    task task1 = new task(oilChange, 60, "Filtro ladiou", 1, "Ekremei");
                    task task2 = new task(filterChange, 30, "Filtro aeros", 2, "Oloklhrwmenh");
                    
                    System.out.println("Leptomeries ergasias 1:");
                    System.out.println("Onoma episkeyhs: " + task1.getRepair().getName());
                    System.out.println("Kostos episkeyhs: " + task1.getRepair().getCost());
                    System.out.println("Diarkeia: " + task1.getDuration());
                    System.out.println("Onoma Antallaktikou: " + task1.getPartName());
                    System.out.println("Arithmos antallaktikou: " + task1.getPartNumber());
                    System.out.println("Katastash episkeyhs: " + task1.getTaskCondition());

                    System.out.println();

                    System.out.println("Leptomeries ergasias 2:");
                    System.out.println("Onoma episkeyhs: " + task2.getRepair().getName());
                    System.out.println("Kostos episkeyhs: " + task2.getRepair().getCost());
                    System.out.println("Diarkeia: " + task2.getDuration());
                    System.out.println("Onoma Antallaktikou: " + task2.getPartName());
                    System.out.println("Arithmos antallaktikou: " + task2.getPartNumber());
                    System.out.println("Katastash episkeyhs: " + task2.getTaskCondition());
                                        
                    
                	break;
                case 0:
                    System.out.println("Eksodos...");
                    break;
                default:
                    System.out.println("Lathos Epilogh. Parakalw dokimaste ksana.");
                    break;
            }

            System.out.println(); // Print a blank line for readability

        } while (choice != 0);

        scanner.close();
    }
		


	}

