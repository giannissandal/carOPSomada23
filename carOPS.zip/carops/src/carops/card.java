package carops;

public class card {

	private String name;
	private String surname;
	private float phoneNumber;
	private String address;
	private String email;
	private String plateNumber;
	private String carBrand;
	private String carModel;
	private int manufactureYear;
	private int cc;
	private Double load;
	private String decision;
	
	
	public card() {
        // Default constructor with no parameters
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setPhoneNumber(float phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }
    
    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public float getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public String toString() {
        return "Card Details:" +
                "\nName: " + name +
                "\nSurname: " + surname +
                "\nPhone Number: " + phoneNumber +
                "\nAddress: " + address +
                "\nEmail: " + email +
                "\nPlate Number: " + plateNumber;
    }

	

	public void createCard(int name, int surname, int phoneNumber, int address, int email, int plateNumber, int carBrand, int carModel, int manufactureYear, int cc, int load) {
		// TODO - implement card.createCard
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param decision
	 */
	public void setDecision(String decision) {
		this.decision = decision;
	}

	private String cardName;
	

	

	
	
}