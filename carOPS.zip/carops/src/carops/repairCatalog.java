package carops;
import java.util.ArrayList;
import java.util.List;

public class repairCatalog {
	
	private List<repair> repairs;

    public repairCatalog() {
        repairs = new ArrayList<>();
    }

    public void addRepair(repair repair) {
        repairs.add(repair);
    }

    public void printRepairs() {
        System.out.println("Katalogos Episkeywn:");
        for (repair repair : repairs) {
            System.out.println("Onoma: " + repair.getName());
            System.out.println("Kostos: " + repair.getCost() + " euro");
            System.out.println();
        }
    }

	public String getRepairName() {
		// TODO - implement repairCatalog.getRepairName
		throw new UnsupportedOperationException();
	}

	public Double getRepairCost() {
		// TODO - implement repairCatalog.getRepairCost
		throw new UnsupportedOperationException();
	}

}